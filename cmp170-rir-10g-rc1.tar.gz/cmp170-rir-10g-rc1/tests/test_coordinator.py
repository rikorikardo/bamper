import contextlib
import copy
import importlib.util
import io
import json
import multiprocessing
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sp=importlib.util.spec_from_file_location('coordinator',ROOT/'cmp170_rir.py')
m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
BDF='0000:01:00.0'
IDENT={'uuid':'GPU-11111111-2222-3333-4444-555555555555','bdf':BDF,'vendor':0x10de,'device':0x2082,'subvendor':0x10de,'subdevice':0x1557}
BASE=dict(rir=[0]*8,main=[m.OLD_MAIN]*2,gate=1,iff=m.STOCK_IFF,iffsw=0,en=0,
          en_prog=1,dis_prog=0,bypass=0,gpc=0x49,fbp=0x840,fbpa=0xc03000,lmr=0x28a,cfg1=0x02669000,active=10,debug=0,fbpa_defective=0,plms=[0xffffffff]*12,feat_plm=0xffffffff)

class MockBackend:
    hash='offline-mock-only'
    def __init__(self):self.s=copy.deepcopy(BASE);self.calls=[];self.fail=None;self.after_burn=None
    def run(self,bdf,mode,profile_id=None):
        self.calls.append((bdf,mode))
        if self.fail==mode:raise RuntimeError('injected '+mode)
        if mode=='--burn':
            self.s['rir']=[m.KEYSTONE]+[0]*7
            if self.after_burn:self.after_burn(self.s)
        return ''
    def snapshot(self,bdf):
        self.calls.append((bdf,'snapshot'))
        if self.fail=='snapshot':raise RuntimeError('injected snapshot failure')
        return copy.deepcopy(self.s)

def child_try_lock(path,q):
    try:
        with m.exclusive_lock(Path(path)):q.put('acquired')
    except m.Refusal:q.put('blocked')

class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.d=Path(self.tmp.name)
        self.b=MockBackend();self.boot='boot-before';self.i=copy.deepcopy(IDENT)
        self.c=m.Coordinator(self.b,self.d,identify=lambda _:copy.deepcopy(self.i),getboot=lambda:self.boot,
            idle=lambda:None,environment=lambda:{'test_env':'fixed'},confirm=lambda _:'BURN '+IDENT['uuid']+' '+BDF)
        self.output=contextlib.redirect_stdout(io.StringIO());self.output.__enter__()
    def tearDown(self):self.output.__exit__(None,None,None);self.tmp.cleanup()
    def prepare(self):return self.c.preflight(BDF)
    def state(self):return m.load_state(self.c.path(self.i))
    def burned(self):return any(mode=='--burn' for _,mode in self.b.calls)
    def verified_setup(self):
        self.prepare();self.c.burn(BDF,True)
        self.boot='boot-after';self.b.s['gate']=0;self.b.s['main']=[m.OLD_MAIN & ~(1<<5)]*2
    def test_encoding(self):self.assertEqual(m.main(['selftest']),0)
    def test_preflight_never_burns(self):self.prepare();self.assertFalse(self.burned())
    def test_happy_path_two_boots(self):
        self.verified_setup();self.c.postburn(BDF,True);self.assertEqual(self.state()['stage'],'verified')
    def test_missing_ack(self):
        self.prepare()
        with self.assertRaises(m.Refusal):self.c.burn(BDF)
        self.assertFalse(self.burned())
    def test_wrong_confirmation(self):
        self.prepare();self.c.confirm=lambda _:'BURN'
        with self.assertRaises(m.Refusal):self.c.burn(BDF,True)
        self.assertFalse(self.burned())
    def test_identity_change(self):
        self.prepare();self.i['uuid']='GPU-foreign'
        with self.assertRaises(m.Refusal):self.c.burn(BDF,True)
        self.assertFalse(self.burned())
    def test_bdf_changed_same_uuid(self):
        self.prepare();self.i['bdf']='0000:42:00.0'
        with self.assertRaises(m.Refusal):self.c.burn(self.i['bdf'],True)
        self.assertFalse(self.burned())
    def test_backend_changed(self):
        self.prepare();self.b.hash='other'
        with self.assertRaises(m.Refusal):self.c.burn(BDF,True)
        self.assertFalse(self.burned())
    def test_corrupt_state(self):
        self.prepare();self.c.path(self.i).write_text('{')
        with self.assertRaises(m.Refusal):self.c.burn(BDF,True)
        self.assertFalse(self.burned())
    def test_no_state(self):
        with self.assertRaises(m.Refusal):self.c.burn(BDF,True)
    def test_enable_zero_dirty_word(self):
        self.b.s['rir'][3]=2
        with self.assertRaises(m.Refusal):self.prepare()
        self.assertFalse(self.burned())
    def test_changed_conditions(self):
        for key,val in [('gate',0),('iffsw',1),('bypass',1),('en_prog',0),('dis_prog',1),('cfg1',3),('main',[0,0])]:
            with self.subTest(key=key):
                self.b.s=copy.deepcopy(BASE);self.prepare();self.b.s[key]=val
                with self.assertRaises(m.Refusal):self.c.burn(BDF,True)
                self.assertFalse(self.burned())
    def test_profile_changed_since_preflight(self):
        self.prepare();self.b.s['fbp']=0x12;self.b.s['fbpa']=0x30c
        with self.assertRaises(m.Refusal):self.c.burn(BDF,True)
        self.assertFalse(self.burned())
    def test_old_boot_preflight(self):
        self.prepare();self.boot='other'
        with self.assertRaises(m.Refusal):self.c.burn(BDF,True)
        self.assertFalse(self.burned())
    def test_durable_intent_failure(self):
        self.prepare()
        with patch.object(m,'atomic_json',side_effect=OSError('fsync failed')):
            with self.assertRaises(OSError):self.c.burn(BDF,True)
        self.assertFalse(self.burned())
    def test_native_failure_blocks_retry_and_preflight(self):
        self.prepare();self.b.fail='--burn'
        with self.assertRaises(RuntimeError):self.c.burn(BDF,True)
        self.assertEqual(self.state()['stage'],'uncertain')
        self.b.fail=None
        with self.assertRaises(m.Refusal):self.c.burn(BDF,True)
        with self.assertRaises(m.Refusal):self.prepare()
        self.assertEqual(sum(mode=='--burn' for _,mode in self.b.calls),1)
    def test_keyboard_interrupt_is_not_swallowed(self):
        self.prepare()
        old=self.b.run
        def run(bdf,mode,profile_id=None):
            if mode=='--burn':raise KeyboardInterrupt
            return old(bdf,mode,profile_id)
        self.b.run=run
        with self.assertRaises(KeyboardInterrupt):self.c.burn(BDF,True)
        self.assertEqual(self.state()['stage'],'uncertain')
    def test_save_after_burn_failure_keeps_prior_blocking_intent(self):
        self.prepare();real=self.c.save;count=[0]
        def save(p,st):
            count[0]+=1
            if count[0]>1:raise OSError('disk failed after command')
            return real(p,st)
        self.c.save=save
        with self.assertRaises(OSError):self.c.burn(BDF,True)
        self.assertEqual(self.state()['stage'],'programming')
        with self.assertRaises(m.Refusal):self.c.burn(BDF,True)
    def test_immediate_unexpected_rir(self):
        self.prepare();self.b.after_burn=lambda s:s['rir'].__setitem__(3,2)
        with self.assertRaises(m.Refusal):self.c.burn(BDF,True)
        self.assertEqual(self.state()['stage'],'uncertain')
    def test_same_boot_postburn_refused(self):
        self.prepare();self.c.burn(BDF,True)
        with self.assertRaises(m.Refusal):self.c.postburn(BDF,True)
    def test_no_power_attestation(self):
        self.verified_setup()
        with self.assertRaises(m.Refusal):self.c.postburn(BDF,False)
    def test_each_required_postburn_field(self):
        self.verified_setup();good=copy.deepcopy(self.b.s)
        cases=[('gate',1),('main',[m.OLD_MAIN & ~(1<<5),m.OLD_MAIN]),('iff',0),('iffsw',1),('rir',[m.KEYSTONE,2,0,0,0,0,0,0]),('cfg1',0),('bypass',1)]
        for key,val in cases:
            with self.subTest(key=key):
                self.b.s=copy.deepcopy(good);self.b.s[key]=val
                with self.assertRaises(m.Refusal):self.c.postburn(BDF,True)
                self.assertNotEqual(self.state()['stage'],'verified')
    def test_snapshot_read_failure(self):
        self.verified_setup();self.b.fail='snapshot'
        with self.assertRaises(RuntimeError):self.c.postburn(BDF,True)
        self.assertNotEqual(self.state()['stage'],'verified')
    def test_readback_invalid(self):
        for field in ('gate','iff','en_prog','fbp'):
            s=copy.deepcopy(BASE);s[field]=0xffffffff
            with self.assertRaises(m.Refusal):m.profile(s)
    def test_clients_refuse_before_controller(self):
        self.c.idle=lambda:(_ for _ in ()).throw(m.Refusal('GPU in use'))
        with self.assertRaises(m.Refusal):self.prepare()
        self.assertEqual(self.b.calls,[])
    def test_unsupported_driver_refused_before_backend(self):
        self.c.environment=lambda:(_ for _ in ()).throw(m.Refusal('unsupported version'))
        with self.assertRaises(m.Refusal):self.prepare()
        self.assertEqual(self.b.calls,[])
    def test_no_raw_or_testburn_cli(self):
        for args in [['testburn'],['unlock'],['preflight','--raw','0x820000=2']]:
            with contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):m.main(args)
    def test_invalid_bdf(self):
        for b in ('../../dev/mem','0000:41:00.0;id','0000:41:20.0','0000:41:00.8','-4'):
            with self.assertRaises(m.Refusal):m.normalize_bdf(b)
    def test_normalize_bdf(self):self.assertEqual(m.normalize_bdf('01:00.0'),BDF)
    def test_process_lock(self):
        lock=self.d/'lock';q=multiprocessing.Queue()
        with m.exclusive_lock(lock):
            p=multiprocessing.Process(target=child_try_lock,args=(str(lock),q));p.start();p.join(5)
            self.assertFalse(p.is_alive());self.assertEqual(q.get(timeout=1),'blocked')
    def test_tampered_state_permissions(self):
        self.prepare();os.chmod(self.c.path(self.i),0o644)
        with self.assertRaises(m.Refusal):self.c.burn(BDF,True)
    def test_verified_history_not_overwritten(self):
        self.verified_setup();self.c.postburn(BDF,True)
        with self.assertRaises(m.Refusal):self.prepare()
        with self.assertRaises(m.Refusal):self.c.burn(BDF,True)
    def test_native_source_preserves_one_command_site(self):
        src=(ROOT/'native/rirburn.c').read_text()
        self.assertEqual(src.count('wr32(c, R_FUSECTRL, CMD_WRITE);'),1)
        self.assertIn('rc = preflight(c);',src)
        self.assertIn('if (rir[i] != 0)',src)
        self.assertIn('if (row0 != TARGET_ROW0 || row1 != TARGET_ROW1)',src)
    def test_legacy_finally_return_regression(self):
        import ast
        tree=ast.parse((ROOT/'cmp170_rir.py').read_text())
        for node in ast.walk(tree):
            if isinstance(node,ast.Try):
                self.assertFalse(any(isinstance(n,ast.Return) for stmt in node.finalbody for n in ast.walk(stmt)))
    def test_live_identity_is_not_tied_to_lab_slot_or_uuid(self):
        m.validate_identity(dict(IDENT, uuid='GPU-abcdabcd-2222-3333-4444-555555555555',
                                 bdf='0001:41:00.0'))
        for field, value in [('uuid','GPU-other'),('bdf','0000:05:20.0'),
                             ('subdevice',0x1555),('device',0x20c2)]:
            with self.subTest(field=field),self.assertRaises(m.Refusal):
                m.validate_identity(dict(IDENT, **{field: value}))

    def test_supported_driver_requires_kernel_abi_and_matching_srcversion(self):
        for marker, version in m.DRIVER_BUILDS.items():
            good={'kernel':'test-kernel','disk_vermagic':'test-kernel SMP',
                  'machine':'x86_64',
                  'version_text':'NVIDIA UNIX Open Kernel Module for x86_64 615.71.09',
                  'disk_version':'615.71.09','disk_marker':marker,
                  'loaded_srcversion':version,'disk_srcversion':version}
            m.validate_environment(good)
            for key,value in [('kernel','other'),('disk_version','610.43.03'),
                              ('disk_marker','unknown'),('loaded_srcversion','wrong'),
                              ('disk_srcversion','wrong'),('machine','aarch64'),
                              ('version_text','NVIDIA proprietary 615.71.09')]:
                with self.subTest(marker=marker, field=key),self.assertRaises(m.Refusal):
                    m.validate_environment(dict(good, **{key:value}))

    def test_snapshot_changes_while_operator_confirms(self):
        self.prepare()
        def confirm(_):
            self.b.s.update(gpc=0x85,fbpa_defective=0xc03000)
            return 'BURN '+IDENT['uuid']+' '+BDF
        self.c.confirm=confirm
        with self.assertRaises(m.Refusal):
            self.c.burn(BDF,True)
        self.assertFalse(self.burned())

    def test_prepared_card_may_be_audited_again_at_new_bdf(self):
        self.prepare()
        self.i['bdf']='0000:08:00.0'
        state=self.c.preflight(self.i['bdf'])
        self.assertEqual(state['identity'],self.i)
        self.assertEqual(self.state()['stage'],'prepared')

    def test_two_cards_keep_separate_histories(self):
        first=self.prepare()
        self.i.update(uuid='GPU-aaaa1111-2222-3333-4444-555555555555')
        self.b.s.update(gpc=0x85,fbpa_defective=0xc03000)
        second=self.prepare()
        self.assertEqual(first['profile_id'],'gpc49')
        self.assertEqual(second['profile_id'],'gpc85')
        self.assertEqual(m.load_state(self.c.path(IDENT)),first)

    def test_environment_changed_since_preflight(self):
        self.prepare();self.c.environment=lambda:{'test_env':'changed'}
        with self.assertRaises(m.Refusal):self.c.burn(BDF,True)
        self.assertFalse(self.burned())
    def test_environment_changed_during_preflight(self):
        seen=iter([{'env':'before'},{'env':'after'}]);self.c.environment=lambda:next(seen)
        with self.assertRaises(m.Refusal):self.prepare()
        self.assertIsNone(self.state());self.assertFalse(self.burned())
    def test_environment_changed_after_confirmation(self):
        self.prepare()
        def confirm(_):
            self.c.environment=lambda:{'test_env':'changed'}
            return 'BURN '+IDENT['uuid']+' '+BDF
        self.c.confirm=confirm
        with self.assertRaises(m.Refusal):self.c.burn(BDF,True)
        self.assertEqual(self.state()['stage'],'prepared');self.assertFalse(self.burned())
    def test_environment_changed_after_programming_blocks_retry(self):
        self.prepare()
        self.b.after_burn=lambda _:setattr(self.c,'environment',lambda:{'test_env':'changed'})
        with self.assertRaises(m.Refusal):self.c.burn(BDF,True)
        self.assertEqual(self.state()['stage'],'uncertain')
        with self.assertRaises(m.Refusal):self.c.burn(BDF,True)
        self.assertEqual(sum(mode=='--burn' for _,mode in self.b.calls),1)
    def test_postburn_environment_changed(self):
        self.verified_setup();self.c.environment=lambda:{'test_env':'changed'}
        with self.assertRaises(m.Refusal):self.c.postburn(BDF,True)
        self.assertEqual(self.state()['stage'],'written-await-powercycle')
    def test_old_schema_not_overwritten(self):
        self.prepare();path=self.c.path(self.i);s=self.state();s['schema']=2;m.atomic_json(path,s)
        before=path.read_bytes()
        with self.assertRaises(m.Refusal):self.prepare()
        self.assertEqual(before,path.read_bytes());self.assertFalse(self.burned())
    def test_snapshot_profile_extra_guards(self):
        for field,value in [('gpc',0x45),('fbp',0x10000840),('fbpa',0xffc03000),
                            ('fbpa_defective',0xc03000),('debug',2),('feat_plm',0xffffff8f),
                            ('plms',[0xffffffff]*11+[0xffffff8f])]:
            s=copy.deepcopy(BASE);s[field]=value
            with self.subTest(field=field),self.assertRaises(m.Refusal):m.profile(s)
    def test_malformed_snapshot_arrays(self):
        for field,value in [('rir',None),('main',{}),('plms',True),('plms',[0xffffffff]*11)]:
            s=copy.deepcopy(BASE);s[field]=value
            with self.subTest(field=field),self.assertRaises(m.Refusal):m.check_snapshot(s)
    def test_core_burn_function_unchanged_from_v2(self):
        import hashlib
        src=(ROOT/'native/rirburn.c').read_text()
        core=src[src.index('static int do_burn('):src.index('\nstatic void usage(')]
        pins=json.loads((ROOT/'SOURCE-PROVENANCE.json').read_text())
        self.assertEqual(hashlib.sha256(core.encode()).hexdigest(),pins['v2_core_do_burn_sha256'])
    def test_historical_masks_and_identity_validate_from_v3(self):
        baseline=json.loads((ROOT/'reference/original-v3-OWNER-BASELINE.json').read_text())
        m.validate_identity(baseline['identity'])
        self.assertEqual(m.profile(baseline['snapshot']),'gpc85')

    def test_native_snapshot_serialization_matches_owner_profile(self):
        log=(ROOT/'tests/native-mock-results.txt').read_text()
        rows=[x[len('SNAPSHOT_JSON:'):] for x in log.splitlines() if x.startswith('SNAPSHOT_JSON:')]
        self.assertEqual(len(rows),1)
        value=json.loads(rows[0]);m.profile(value)
        self.assertEqual(value,BASE)
    def test_dangling_state_symlink_is_not_treated_as_absent(self):
        path=self.c.path(self.i);path.symlink_to(self.d/'missing-history')
        with self.assertRaises(m.Refusal):self.prepare()
        self.assertTrue(path.is_symlink());self.assertFalse(self.burned())

class Card2Binding(unittest.TestCase):
    def test_owner_card2_snapshot_matches_exact_profile(self):
        observed=json.loads((ROOT/'CARD2-OBSERVED.json').read_text())
        m.validate_identity(observed['identity']);m.profile(observed['snapshot'])
        self.assertEqual(observed['snapshot'],BASE)
    def test_native_cli_requires_coordinator_handoff(self):
        native=ROOT/'native/rirburn'
        attempts=([str(native),BDF,'--burn','--i-understand-rir-is-permanent'],
                  [str(native),BDF,'--commit','gpc49'])
        for args in attempts:
            result=subprocess.run(args,stdin=subprocess.DEVNULL,capture_output=True)
            self.assertEqual(result.returncode,2)

if __name__=='__main__':unittest.main()
