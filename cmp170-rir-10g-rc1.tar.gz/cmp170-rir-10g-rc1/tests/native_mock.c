/* Offline controller model. Does NOT establish actual fuse behavior. */
#define CMP170_OFFLINE_TEST 1
#define main upstream_main_not_executed
#define usleep mock_usleep
#include "../native/rirburn.c"
#undef main
#undef usleep
#include <assert.h>

static uint32_t regs[0x1000000 / 4], rir_model[8], main_model[512];
static unsigned commands, events;
static int reject_rwl, timeout_write, corrupt_verify, stop_before;

int mock_usleep(useconds_t x) { (void)x; return 0; }
uint32_t mock_rd(uint32_t off)
{
    assert((off & 3) == 0 && off < sizeof(regs));
    return regs[off/4];
}
void mock_wr(uint32_t off, uint32_t val)
{
    uint32_t addr;
    assert((off & 3) == 0 && off < sizeof(regs));
    events++;
    if (off == R_DEBUGCTRL && reject_rwl) val &= ~RWL;
    regs[off/4]=val;
    if (off != R_FUSECTRL) return;
    addr=regs[R_FUSEADDR/4];
    if (val == CMD_READ) {
        regs[R_FUSERDATA/4] = (regs[R_DEBUGCTRL/4] & RWL) ? rir_model[addr & 7] : main_model[addr & 511];
    } else if (val == CMD_WRITE) {
        commands++;
        assert((regs[R_DEBUGCTRL/4] & RWL) != 0);
        assert(addr == TARGET_ROW);
        assert(regs[R_FUSEWDATA/4] == TARGET_VALUE);
        rir_model[0] = corrupt_verify ? 2 : TARGET_VALUE;
    }
    regs[R_FUSECTRL/4] = (val == CMD_WRITE && timeout_write) ? (3u << 16) : STATE_IDLE;
    if (stop_before && val == CMD_READ) g_stop=1;
}
static struct ctx setup(void)
{
    struct ctx c={0};
    memset(regs,0,sizeof(regs));memset(rir_model,0,sizeof(rir_model));memset(main_model,0,sizeof(main_model));
    commands=events=0;reject_rwl=timeout_write=corrupt_verify=stop_before=0;g_stop=0;
    c.bar0=regs;c.size=sizeof(regs);strcpy(c.bdf,"0000:01:00.0");c.boot0=0x170000a1;c.orig_ctrl=STATE_IDLE;
    regs[R_FUSECTRL/4]=STATE_IDLE;
    regs[R_OPT_FBP_DISABLE/4]=0x840;regs[R_OPT_FBPA_DISABLE/4]=0xc03000;
    regs[R_OPT_FBPA_DEFECTIVE/4]=0;
    for (unsigned i=0;i<12;i++) regs[(0x8200d0+4*i)/4]=0xffffffff;
    regs[0x823804/4]=0xffffffff;
    regs[R_FUSE_EN_PROGRAM/4]=1;regs[R_DISABLE_SW_OVERRIDE_STATUS/4]=1;
    regs[R_IFF_RECORD/4]=0x01fb01e8;
    regs[R_OPT_GPC_DISABLE/4]=0x49u;regs[R_LMR/4]=EXPECT_LMR;
    regs[R_CFG1/4]=EXPECT_CFG1;regs[R_FBPA_NUM_ACTIVE/4]=EXPECT_FBPA_ACTIVE;
    main_model[0]=TARGET_ROW0;main_model[1]=TARGET_ROW1;
    return c;
}
int main(void)
{
    struct ctx c;unsigned n=0;
    c=setup();assert(do_burn(&c)==0 && commands==1);n++;
    c=setup();rir_model[3]=2;assert(do_burn(&c)!=0 && commands==0);n++;
    c=setup();regs[R_DISABLE_SW_OVERRIDE_STATUS/4]=0;assert(do_burn(&c)!=0 && commands==0);n++;
    c=setup();main_model[1]^=0x20;assert(do_burn(&c)!=0 && commands==0);n++;
    c=setup();regs[R_FUSE_BYPASS_STATUS/4]=1;assert(do_burn(&c)!=0 && commands==0);n++;
    c=setup();regs[R_OPT_FBPA_DISABLE/4]=0;assert(do_burn(&c)!=0 && commands==0);n++;
    c=setup();reject_rwl=1;assert(do_burn(&c)!=0 && commands==0);n++;
    c=setup();regs[R_FUSECTRL/4]=3u<<16;assert(do_burn(&c)!=0 && commands==0);n++;
    c=setup();timeout_write=1;assert(do_burn(&c)!=0 && commands==1);n++;
    c=setup();corrupt_verify=1;assert(do_burn(&c)!=0 && commands==1);n++;
    c=setup();stop_before=1;assert(do_burn(&c)!=0 && commands==0);n++;
    c=setup();regs[R_EN_SW_OVERRIDE/4]=1;assert(do_burn(&c)!=0 && commands==0 && regs[R_EN_SW_OVERRIDE/4]==1);n++;
    c=setup();regs[R_OPT_GPC_DISABLE/4]=0x45;assert(do_burn(&c)!=0 && commands==0);n++;
    c=setup();regs[R_OPT_FBPA_DEFECTIVE/4]=0xc03000;assert(do_burn(&c)!=0 && commands==0);n++;
    c=setup();regs[R_OPT_FBP_DISABLE/4]|=0x10000000;assert(do_burn(&c)!=0 && commands==0);n++;
    for(unsigned i=0;i<12;i++) {
        c=setup();regs[(0x8200d0+4*i)/4]=0xffffff8f;
        assert(do_burn(&c)!=0 && commands==0);n++;
    }
    c=setup();regs[0x823804/4]=0xffffff8f;assert(do_burn(&c)!=0 && commands==0);n++;
    c=setup();assert(snapshot(&c)==0 && commands==0);n++;
    c=setup();c.expected_profile="gpc85";assert(do_burn(&c)!=0 && commands==0);n++;
    c=setup();c.expected_profile="gpc85";regs[R_OPT_GPC_DISABLE/4]=0x85;
    regs[R_OPT_FBPA_DEFECTIVE/4]=0xc03000;
    assert(do_burn(&c)==0 && commands==1);n++;
    printf("NATIVE_MOCK_OK: %u scenarios; zero real MMIO.\n",n);
    return 0;
}
