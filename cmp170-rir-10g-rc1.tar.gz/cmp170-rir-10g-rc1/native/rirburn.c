// SPDX-License-Identifier: MIT
/* CMP170HX 10 GiB RIR backend. Use through cmp170_rir.py. */

#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

/* Fuse controller */
#define R_FUSECTRL                    0x00820000u
#define R_FUSEADDR                    0x00820004u
#define R_FUSERDATA                   0x00820008u
#define R_FUSEWDATA                   0x0082000Cu
#define R_DEBUGCTRL                   0x00820060u

/* Gate / state */
#define R_EN_SW_OVERRIDE              0x00820040u
#define R_DISABLE_SW_OVERRIDE_STATUS  0x00820084u
#define R_FUSE_EN_PROGRAM             0x00820078u
#define R_FUSE_DIS_PROGRAM            0x0082007Cu
#define R_FUSE_BYPASS_STATUS          0x00820080u
#define R_IFF_RECORD                  0x00820050u
#define R_IFF_SW_FUSING               0x00820088u
#define R_FUSE_FEAT_OVR_DIS           0x008203F0u

/* Floorsweep / geometry */
#define R_OPT_GPC_DISABLE             0x00820350u
#define R_OPT_FBP_DISABLE             0x00820364u
#define R_OPT_FBPA_DISABLE            0x00820368u
#define R_OPT_FBPA_DEFECTIVE          0x008205D0u
#define R_LMR                         0x00100CE0u
#define R_CFG1                        0x009A0204u
#define R_FBPA_NUM_ACTIVE             0x009A0164u

#define R_PMC_BOOT_0                  0x00000000u

#define CMD_IDLE                      0u
#define CMD_READ                      1u
#define CMD_WRITE                     2u
#define STATE_MASK                    (0x1Fu << 16)
#define STATE_IDLE                    (4u << 16)
#define RWL                           (1u << 1)

#define TARGET_ROW                    0u
#define TARGET_VALUE                  0x00950015u
#define TARGET_ROW0                   0x53557C3Du
#define TARGET_ROW1                   0x53557C3Du

#define EXPECT_LMR                    0x28Au
#define EXPECT_CFG1                   0x02669000u
#define EXPECT_FBPA_ACTIVE            10u

#define RIR_ROWS                      8

struct ctx {
    int fd;
    volatile uint32_t *bar0;
    size_t size;
    char bdf[64];
    uint32_t boot0;
    uint32_t orig_ctrl;
    uint32_t orig_addr;
    uint32_t orig_debug;
    const char *expected_profile;
};

static volatile sig_atomic_t g_stop;
static struct ctx g_ctx;
static int g_open;
static int g_read_started;

static void on_signal(int sig)
{
    (void)sig;
    g_stop = 1;
}

#ifdef CMP170_OFFLINE_TEST
/* Compile-time-only injection used by tests/native_mock.c; no runtime switch. */
extern uint32_t mock_rd(uint32_t);
extern void mock_wr(uint32_t, uint32_t);
static inline uint32_t rd32(struct ctx *c, uint32_t off)
{ (void)c; return mock_rd(off); }
static inline void wr32(struct ctx *c, uint32_t off, uint32_t val)
{ (void)c; mock_wr(off, val); }
#else
static inline uint32_t rd32(struct ctx *c, uint32_t off)
{
    return c->bar0[off / 4];
}

static inline void wr32(struct ctx *c, uint32_t off, uint32_t val)
{
    c->bar0[off / 4] = val;
    __sync_synchronize();
}

#endif

static void clear_rwl(struct ctx *c)
{
    uint32_t v;
    if (!c || !c->bar0)
        return;
    v = rd32(c, R_DEBUGCTRL);
    if (v & RWL)
        wr32(c, R_DEBUGCTRL, v & ~RWL);
}

static void restore_regs(struct ctx *c)
{
    if (!c || !c->bar0)
        return;
    clear_rwl(c);
    wr32(c, R_FUSEADDR, c->orig_addr);
    wr32(c, R_FUSECTRL, CMD_IDLE); /* never replay a saved READ/WRITE opcode */
}

static void cleanup(void)
{
    if (!g_open)
        return;
    if (g_read_started)
        restore_regs(&g_ctx);
    munmap((void *)g_ctx.bar0, g_ctx.size);
    if (g_ctx.fd >= 0)
        close(g_ctx.fd);
    g_open = 0;
}

static int read_sys_hex(const char *path, unsigned *out)
{
    FILE *f = fopen(path, "r");
    int rc;

    if (!f)
        return -1;
    rc = fscanf(f, "%x", out);
    fclose(f);
    return rc == 1 ? 0 : -1;
}

static int valid_bdf(const char *bdf)
{
    size_t n = strlen(bdf);
    size_t i;

    if (n != 12 || bdf[4] != ':' || bdf[7] != ':' || bdf[10] != '.')
        return 0;
    for (i = 0; i < n; i++) {
        if (i == 4 || i == 7 || i == 10)
            continue;
        if (!((bdf[i] >= '0' && bdf[i] <= '9') ||
              (bdf[i] >= 'a' && bdf[i] <= 'f') ||
              (bdf[i] >= 'A' && bdf[i] <= 'F')))
            return 0;
    }
    return 1;
}

static int open_gpu(struct ctx *c, const char *bdf)
{
    char path[256];
    struct stat st;
    unsigned vendor = 0, device = 0;

    memset(c, 0, sizeof(*c));
    c->fd = -1;
    if (!valid_bdf(bdf)) {
        fprintf(stderr, "error: invalid BDF '%s'\n", bdf);
        return -1;
    }
    snprintf(c->bdf, sizeof(c->bdf), "%s", bdf);

    snprintf(path, sizeof(path), "/sys/bus/pci/devices/%s/vendor", bdf);
    if (read_sys_hex(path, &vendor) || vendor != 0x10de) {
        fprintf(stderr, "error: %s is not an NVIDIA device (vendor=0x%04x)\n",
                bdf, vendor);
        return -1;
    }
    snprintf(path, sizeof(path), "/sys/bus/pci/devices/%s/device", bdf);
    if (read_sys_hex(path, &device) || device != 0x2082) {
        fprintf(stderr, "error: %s is 10de:%04x, expected 10de:2082\n",
                bdf, device);
        return -1;
    }
    snprintf(path, sizeof(path), "/sys/bus/pci/devices/%s/subsystem_vendor", bdf);
    if (read_sys_hex(path, &vendor) || vendor != 0x10de) {
        fprintf(stderr, "error: expected subsystem vendor 10de\n");
        return -1;
    }
    snprintf(path, sizeof(path), "/sys/bus/pci/devices/%s/subsystem_device", bdf);
    if (read_sys_hex(path, &device) || device != 0x1557) {
        fprintf(stderr, "error: expected subsystem device 1557\n");
        return -1;
    }

    snprintf(path, sizeof(path), "/sys/bus/pci/devices/%s/resource0", bdf);
    c->fd = open(path, O_RDWR | O_SYNC);
    if (c->fd < 0) {
        fprintf(stderr, "error: cannot open %s: %s\n", path, strerror(errno));
        return -1;
    }
    if (fstat(c->fd, &st) || st.st_size < 0x1000000) {
        fprintf(stderr, "error: bad resource0 size\n");
        close(c->fd);
        c->fd = -1;
        return -1;
    }
    c->size = (size_t)st.st_size;
    c->bar0 = mmap(NULL, c->size, PROT_READ | PROT_WRITE, MAP_SHARED, c->fd, 0);
    if (c->bar0 == MAP_FAILED) {
        fprintf(stderr, "error: mmap resource0 failed: %s\n", strerror(errno));
        close(c->fd);
        c->fd = -1;
        c->bar0 = NULL;
        return -1;
    }

    c->boot0 = rd32(c, R_PMC_BOOT_0);
    if (c->boot0 != 0x170000a1u) {
        fprintf(stderr,
                "error: PMC_BOOT_0=0x%08x, expected GA100 arch 0x17\n",
                c->boot0);
        munmap((void *)c->bar0, c->size);
        close(c->fd);
        c->fd = -1;
        c->bar0 = NULL;
        return -1;
    }

    /* Refuse before any controller writes; never replay an active command. */
    if ((rd32(c, R_FUSECTRL) & STATE_MASK) != STATE_IDLE ||
        rd32(c, R_DEBUGCTRL) != 0) {
        fprintf(stderr, "error: controller not clean/idle; no writes performed\n");
        munmap((void *)c->bar0, c->size);
        close(c->fd);
        c->fd = -1;
        c->bar0 = NULL;
        return -1;
    }
    c->orig_ctrl = rd32(c, R_FUSECTRL);
    c->orig_addr = rd32(c, R_FUSEADDR);
    c->orig_debug = rd32(c, R_DEBUGCTRL);

    g_ctx = *c;
    g_open = 1;
    atexit(cleanup);
    return 0;
}

static int poll_idle(struct ctx *c, int timeout_ms)
{
    int i;

    for (i = 0; i < timeout_ms; i++) {
        if (g_stop)
            return -2;
        if ((rd32(c, R_FUSECTRL) & STATE_MASK) == STATE_IDLE)
            return 0;
        usleep(1000);
    }
    return -1;
}

static int read_main_row(struct ctx *c, uint32_t row, uint32_t *val)
{
    int rc;

    g_read_started = 1;
    clear_rwl(c);
    wr32(c, R_FUSECTRL, CMD_IDLE);
    wr32(c, R_FUSEADDR, row & 0x1ffu);
    wr32(c, R_FUSECTRL, CMD_READ);
    rc = poll_idle(c, 1000);
    if (rc)
        return rc;
    *val = rd32(c, R_FUSERDATA);
    wr32(c, R_FUSECTRL, CMD_IDLE);
    return 0;
}

static int read_rir_all(struct ctx *c, uint32_t rows[RIR_ROWS])
{
    uint32_t dc;
    uint32_t check;
    int i, rc;

    dc = rd32(c, R_DEBUGCTRL);
    g_read_started = 1;
    wr32(c, R_FUSECTRL, CMD_IDLE);
    wr32(c, R_DEBUGCTRL, dc | RWL);
    check = rd32(c, R_DEBUGCTRL);
    if (!(check & RWL)) {
        fprintf(stderr, "error: DEBUGCTRL.RWL did not latch (0x%08x)\n",
                check);
        return -1;
    }

    for (i = 0; i < RIR_ROWS; i++) {
        if (g_stop) {
            clear_rwl(c);
            return -2;
        }
        wr32(c, R_FUSEADDR, (uint32_t)i);
        wr32(c, R_FUSECTRL, CMD_READ);
        rc = poll_idle(c, 1000);
        if (rc) {
            clear_rwl(c);
            return rc;
        }
        rows[i] = rd32(c, R_FUSERDATA);
    }

    clear_rwl(c);
    wr32(c, R_FUSECTRL, CMD_IDLE);
    return 0;
}

static int fail(const char *what)
{
    fprintf(stderr, "PREFLIGHT FAILED: %s\n", what);
    return -1;
}

#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))

/* Observed profiles. Check complete values, including defective mask. */
static const struct
{
    const char *name;
    uint32_t gpc;
    uint32_t defective;
} known_profiles[] = {
    { "gpc85", 0x85u, 0x00c03000u },
    { "gpc49", 0x49u, 0u },
};

static int preflight(struct ctx *c)
{
    uint32_t en_prog, dis_prog, bypass, en_sw, dis_status;
    uint32_t debug, iff_rec, iff_sw, feat_dis;
    uint32_t rir[RIR_ROWS];
    uint32_t row0 = 0, row1 = 0;
    uint32_t fbp, fbpa, gpc, lmr, cfg1, active, defective;
    const char *profile = NULL;
    unsigned int i;
    int rc;

    printf("== preflight %s ==\n", c->bdf);
    printf("  PMC_BOOT_0            = 0x%08x (GA100 arch 0x%x)\n",
           c->boot0, (c->boot0 >> 24) & 0x1fu);

    if ((rd32(c, R_FUSECTRL) & STATE_MASK) != STATE_IDLE)
        return fail("FUSECTRL is not idle");

    fbp    = rd32(c, R_OPT_FBP_DISABLE);
    fbpa   = rd32(c, R_OPT_FBPA_DISABLE);
    gpc    = rd32(c, R_OPT_GPC_DISABLE);
    lmr    = rd32(c, R_LMR);
    cfg1   = rd32(c, R_CFG1);
    active = rd32(c, R_FBPA_NUM_ACTIVE);
    defective = rd32(c, R_OPT_FBPA_DEFECTIVE);

    for (i = 0; i < ARRAY_SIZE(known_profiles); i++) {
        if (gpc == known_profiles[i].gpc && defective == known_profiles[i].defective) {
            profile = known_profiles[i].name;
            break;
        }
    }
    if (profile == NULL || fbp != 0x840u || fbpa != 0xc03000u)
        return fail("unknown floorsweep profile; refusing");
    if (c->expected_profile != NULL && strcmp(profile, c->expected_profile) != 0)
        return fail("floorsweep profile changed since coordinator snapshot");

    printf("  profile               = %s\n", profile);
    for (i = 0; i < 12; i++) {
        if (rd32(c, 0x008200d0u + 4u * i) != 0xffffffffu)
            return fail("Recorded PLM bank access state changed");
    }
    if (rd32(c, 0x00823804u) != 0xffffffffu)
        return fail("Recorded FEAT PLM access state changed");

    en_prog   = rd32(c, R_FUSE_EN_PROGRAM);
    dis_prog  = rd32(c, R_FUSE_DIS_PROGRAM);
    bypass    = rd32(c, R_FUSE_BYPASS_STATUS);
    en_sw     = rd32(c, R_EN_SW_OVERRIDE);
    dis_status= rd32(c, R_DISABLE_SW_OVERRIDE_STATUS);
    debug     = rd32(c, R_DEBUGCTRL);
    iff_rec   = rd32(c, R_IFF_RECORD);
    iff_sw    = rd32(c, R_IFF_SW_FUSING);
    feat_dis  = rd32(c, R_FUSE_FEAT_OVR_DIS);

    printf("  FUSE_EN_PROGRAM       = %u\n", en_prog);
    printf("  FUSE_DIS_PROGRAM      = %u\n", dis_prog);
    printf("  FUSE_BYPASS_STATUS    = %u\n", bypass);
    printf("  EN_SW_OVERRIDE        = %u\n", en_sw);
    printf("  DISABLE_SW_OVR_STATUS = %u\n", dis_status);
    printf("  DEBUGCTRL             = 0x%08x\n", debug);
    printf("  IFF_RECORD            = 0x%08x\n", iff_rec);
    printf("  IFF_SW_FUSING         = %u\n", iff_sw);
    printf("  FUSE_FEAT_OVR_DIS     = 0x%08x\n", feat_dis);
    printf("  OPT_FBP_DISABLE       = 0x%03x\n", fbp);
    printf("  OPT_FBPA_DISABLE      = 0x%06x\n", fbpa);
    printf("  OPT_GPC_DISABLE       = 0x%02x\n", gpc);
    printf("  LMR                    = 0x%08x\n", lmr);
    printf("  CFG1                   = 0x%08x\n", cfg1);
    printf("  FBPA_NUM_ACTIVE        = %u\n", active);

    if (en_prog != 1)
        return fail("FUSE_EN_PROGRAM != 1");
    if (dis_prog != 0)
        return fail("FUSE_DIS_PROGRAM != 0");
    if (bypass != 0)
        return fail("FUSE_BYPASS_STATUS != 0");
    if (dis_status != 1)
        return fail("DISABLE_SW_OVERRIDE_STATUS != 1 (card is already burned?)");
    if (debug != 0)
        return fail("DEBUGCTRL != 0 (RWL left set?)");
    if (iff_rec != 0x01FB01E8u)
        return fail("IFF_RECORD mismatch");
    if (iff_sw != 0)
        return fail("IFF_SW_FUSING != 0");

    /* This recorded target has EN=0. Refuse instead of changing it to fit. */
    if (en_sw != 0)
        return fail("EN_SW_OVERRIDE differs from recorded target; no auto-clear");

    rc = read_rir_all(c, rir);
    if (rc)
        return fail("RIR read failed");

    printf("  RIR rows:\n");
    for (i = 0; i < RIR_ROWS; i++)
        printf("    row %u: 0x%08x\n", i, rir[i]);
    for (i = 0; i < RIR_ROWS; i++) {
        if (rir[i] != 0)
            return fail("RIR is not blank; refuse to burn");
    }

    rc = read_main_row(c, 0, &row0);
    if (rc)
        return fail("main row 0 read failed");
    rc = read_main_row(c, 1, &row1);
    if (rc)
        return fail("main row 1 read failed");

    printf("  main row 0            = 0x%08x (bit5=%u bit6=%u)\n",
           row0, (row0 >> 5) & 1u, (row0 >> 6) & 1u);
    printf("  main row 1            = 0x%08x (bit5=%u bit6=%u)\n",
           row1, (row1 >> 5) & 1u, (row1 >> 6) & 1u);

    if (row0 != TARGET_ROW0 || row1 != TARGET_ROW1)
        return fail("main row 0/1 do not match the unburned 40 GB profile");
    if (((row0 >> 5) & 1u) != 1u || ((row1 >> 5) & 1u) != 1u)
        return fail("DISABLE_SW_OVERRIDE bit 5 is not set on both copies");
    if (((row0 >> 6) & 1u) != 0u || ((row1 >> 6) & 1u) != 0u)
        return fail("OPT_DEBUG_FEATURE_SW_OVERRIDE_ENABLE bit 6 is not 0");

    if (lmr != EXPECT_LMR)
        return fail("LMR does not match the 40 GB profile");
    if (cfg1 != EXPECT_CFG1)
        return fail("CFG1 does not match the 40 GB profile");
    if (active != EXPECT_FBPA_ACTIVE)
        return fail("FBPA_NUM_ACTIVE does not match the 40 GB profile");

    restore_regs(c);
    printf("PREFLIGHT OK: %s, RIR blank, gate closed, row0/1 intact\n",
           profile);
    return 0;
}

static int snapshot(struct ctx *c)
{
    uint32_t rir[RIR_ROWS], m0, m1;
    unsigned i;
    for (i = 0; i < 12; i++)
        if (rd32(c, 0x008200d0u + 4u * i) != 0xffffffffu)
            return fail("PLM bank access state differs");
    if (rd32(c, 0x00823804u) != 0xffffffffu)
        return fail("FEAT PLM access state differs");
    if (read_rir_all(c, rir) || read_main_row(c, 0, &m0) ||
        read_main_row(c, 1, &m1)) return fail("snapshot read failed");
    printf("SNAPSHOT_JSON:{\"rir\":[");
    for (i=0; i<RIR_ROWS; i++) printf("%s%u", i ? "," : "", rir[i]);
    printf("],\"main\":[%u,%u]", m0, m1);
#define SNAP(name, reg) printf(",\"" name "\":%u", rd32(c, reg))
    SNAP("gate", R_DISABLE_SW_OVERRIDE_STATUS);
    SNAP("iff", R_IFF_RECORD); SNAP("iffsw", R_IFF_SW_FUSING);
    SNAP("en", R_EN_SW_OVERRIDE); SNAP("en_prog", R_FUSE_EN_PROGRAM);
    SNAP("dis_prog", R_FUSE_DIS_PROGRAM); SNAP("bypass", R_FUSE_BYPASS_STATUS);
    SNAP("gpc", R_OPT_GPC_DISABLE); SNAP("fbp", R_OPT_FBP_DISABLE);
    SNAP("fbpa", R_OPT_FBPA_DISABLE); SNAP("lmr", R_LMR);
    SNAP("cfg1", R_CFG1); SNAP("active", R_FBPA_NUM_ACTIVE);
    SNAP("debug", R_DEBUGCTRL); SNAP("fbpa_defective", R_OPT_FBPA_DEFECTIVE);
    SNAP("feat_plm", 0x00823804u);
    printf(",\"plms\":[");
    for (i = 0; i < 12; i++) printf("%s%u", i ? "," : "", rd32(c, 0x008200d0u + 4u * i));
    printf("]");
#undef SNAP
    printf("}\n");
    return 0;
}

static int do_burn(struct ctx *c)
{
    uint32_t dc, check;
    uint32_t rir[RIR_ROWS];
    int i, rc;

    rc = preflight(c);
    if (rc)
        return rc;

    if (g_stop) {
        fprintf(stderr, "ABORT: signal received before write\n");
        return -1;
    }

    printf("\n*** BURN: RIR row %u <- FUSEWDATA 0x%08x ***\n",
           TARGET_ROW, TARGET_VALUE);
    printf("    record 0x0015 -> flat bit 5  (row 0, bit 5)\n");
    printf("    record 0x0095 -> flat bit 37 (row 1, bit 5)\n");
    printf("    CMD_WRITE is issued once; there is no retry.\n\n");

    wr32(c, R_FUSECTRL, CMD_IDLE);
    dc = rd32(c, R_DEBUGCTRL);
    wr32(c, R_DEBUGCTRL, dc | RWL);
    check = rd32(c, R_DEBUGCTRL);
    if (!(check & RWL)) {
        fprintf(stderr, "ABORT: DEBUGCTRL.RWL did not latch (0x%08x)\n",
                check);
        return -1;
    }

    rc = poll_idle(c, 2000);
    if (rc) {
        fprintf(stderr, "ABORT: FUSECTRL not idle before write (%d)\n", rc);
        clear_rwl(c);
        return -1;
    }

    wr32(c, R_FUSEADDR, TARGET_ROW);
    wr32(c, R_FUSEWDATA, TARGET_VALUE);
    wr32(c, R_FUSECTRL, CMD_WRITE);

    rc = poll_idle(c, 5000);
    clear_rwl(c);
    wr32(c, R_FUSECTRL, CMD_IDLE);

    if (rc) {
        fprintf(stderr,
                "ERROR: write did not complete (poll=%d). NO RETRY.\n", rc);
        return -1;
    }

    rc = read_rir_all(c, rir);
    if (rc) {
        fprintf(stderr, "ERROR: RIR verify read failed (%d). NO RETRY.\n", rc);
        return -1;
    }

    printf("  RIR after write:\n");
    for (i = 0; i < RIR_ROWS; i++)
        printf("    row %d: 0x%08x\n", i, rir[i]);

    if (rir[0] != TARGET_VALUE) {
        fprintf(stderr,
                "VERIFY FAILED: row 0 = 0x%08x, expected 0x%08x. NO RETRY.\n",
                rir[0], TARGET_VALUE);
        return -1;
    }
    for (i = 1; i < RIR_ROWS; i++) {
        if (rir[i] != 0) {
            fprintf(stderr,
                    "VERIFY FAILED: row %d changed to 0x%08x. NO RETRY.\n",
                    i, rir[i]);
            return -1;
        }
    }

    printf("VERIFY OK: RIR row 0 = 0x%08x; 14 records remain free.\n",
           rir[0]);
    printf("Cold-boot the host before the functional gate test.\n");
    return 0;
}

static void usage(const char *prog)
{
    fprintf(stderr, "Usage: %s <bdf> --snapshot | <bdf> --preflight <profile> | --selftest\n", prog);
}

static int selftest(void)
{
    uint16_t r5 = (uint16_t)((5u << 2) | 1u);
    uint16_t r37 = (uint16_t)((37u << 2) | 1u);
    uint32_t packed = ((uint32_t)r37 << 16) | r5;

    if (r5 != 0x0015u || r37 != 0x0095u) {
        fprintf(stderr, "selftest FAILED: record encoding\n");
        return 1;
    }
    if (packed != TARGET_VALUE) {
        fprintf(stderr, "selftest FAILED: packed value 0x%08x\n", packed);
        return 1;
    }
    if (((TARGET_ROW0 >> 5) & 1u) != 1u ||
        ((TARGET_ROW1 >> 5) & 1u) != 1u) {
        fprintf(stderr, "selftest FAILED: row bit 5 constants\n");
        return 1;
    }
    printf("selftest OK: 0x0015 + 0x0095 -> 0x%08x\n", packed);
    printf("target row 0/1 = 0x%08x / 0x%08x\n", TARGET_ROW0, TARGET_ROW1);
    return 0;
}

int main(int argc, char **argv)
{
    if (argc == 2 && strcmp(argv[1], "--selftest") == 0)
        return selftest();

    int read_only = argc == 3 && strcmp(argv[2], "--snapshot") == 0;
    int preflight_only = argc == 4 && strcmp(argv[2], "--preflight") == 0;
    int coordinated = argc == 4 && strcmp(argv[2], "--commit") == 0;
    if (!read_only && !preflight_only && !coordinated) {
        usage(argv[0]);
        return 2;
    }

    if (coordinated) {
        struct stat input;
        char intent[64];
        if (fstat(STDIN_FILENO, &input) != 0 || !S_ISFIFO(input.st_mode) ||
            fgets(intent, sizeof(intent), stdin) == NULL ||
            strcmp(intent, "CMP170-RIR-DURABLE-INTENT\n") != 0) {
            fprintf(stderr, "refusing commit without coordinator intent pipe\n");
            return 2;
        }
    }

    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);
    signal(SIGHUP, on_signal);
    if (open_gpu(&g_ctx, argv[1]))
        return 1;

    g_ctx.expected_profile = read_only ? NULL : argv[3];
    int rc = read_only ? snapshot(&g_ctx) :
             preflight_only ? preflight(&g_ctx) : do_burn(&g_ctx);
    cleanup();
    return rc ? 1 : 0;
}
