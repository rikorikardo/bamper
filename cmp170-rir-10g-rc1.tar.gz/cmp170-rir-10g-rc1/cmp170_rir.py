#!/usr/bin/env python3
"""CMP170HX 10 GiB RIR unlocker. See RUNBOOK-170.md for platform qualification."""
import argparse
import contextlib
import fcntl
import glob
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import signal
import stat
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent
STATE_ROOT = Path('/var/lib/cmp170-staged-v2')
LOCK_ROOT = Path('/run/lock/cmp170-staged-v2')
ACTIVE_LOCK_FD = None
SCHEMA = 4
DRIVER_BUILDS = {
    'v1-61571-upstream-2c7e2ecd': '6365EF41061AAA45379C6D2',
    'fleet-hbm-plm-v2-61571': '93DABA9551A34E785A38E63',
}
GEOMETRIES = {
    (0x85, 0xc03000): 'gpc85',
    (0x49, 0): 'gpc49',
}
UUID_PATTERN = r'GPU-[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}'
KEYSTONE = 0x00950015
STOCK_IFF = 0x01fb01e8
OLD_MAIN = 0x53557c3d

class Refusal(RuntimeError):
    pass

def require(ok, why):
    if not ok:
        raise Refusal(why)

def normalize_bdf(bdf):
    bdf = bdf.lower()
    if re.fullmatch(r'[0-9a-f]{2}:[0-9a-f]{2}\.[0-7]', bdf):
        bdf = '0000:' + bdf
    require(bool(re.fullmatch(r'[0-9a-f]{4}:[0-9a-f]{2}:[0-1][0-9a-f]\.[0-7]', bdf)),
            'Invalid PCI BDF')
    return bdf

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

def atomic_json(path, value):
    """fsync file AND directory. Failure is fatal before programming."""
    path = Path(path)
    data = json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2).encode()+b'\n'
    fd, tmp = tempfile.mkstemp(prefix='.pending-', dir=path.parent)
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, 'wb') as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, path)
        dfd = os.open(path.parent, os.O_DIRECTORY)
        try: os.fsync(dfd)
        finally: os.close(dfd)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)

def load_state(path):
    require(not path.is_symlink(), 'State cannot be a symlink')
    if not path.exists(): return None
    st = path.stat()
    require(st.st_uid == os.geteuid() and not st.st_mode & 0o077, 'State permissions must be 0600 and owned by caller')
    try: value = json.loads(path.read_text())
    except (OSError, ValueError) as e: raise Refusal('Cannot read state; refusing to replace it') from e
    require(isinstance(value, dict) and value.get('schema') == SCHEMA, 'Unknown state schema')
    return value

def private_dir(path):
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    require(not path.is_symlink(), 'Private directory cannot be a symlink')
    s=path.stat()
    require(s.st_uid == os.geteuid() and not s.st_mode & 0o077, 'Private directory must be owned and mode 0700: '+str(path))

@contextlib.contextmanager
def exclusive_lock(root=LOCK_ROOT):
    # Global lock intentionally serializes ALL cards and read-engine commands.
    global ACTIVE_LOCK_FD
    private_dir(root)
    fd=os.open(root/'controller.lock', os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW, 0o600)
    try:
        try: fcntl.flock(fd, fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError as e: raise Refusal('Another coordinator owns the controller lock') from e
        ACTIVE_LOCK_FD = fd
        yield
    finally:
        ACTIVE_LOCK_FD = None
        os.close(fd)

def boot_id():
    return Path('/proc/sys/kernel/random/boot_id').read_text().strip()

def identity(bdf):
    """Require currently driver-reported UUID. No state-based guess when unavailable."""
    dev=Path('/sys/bus/pci/devices')/bdf
    def h(name): return int((dev/name).read_text().strip(),16)
    require(h('vendor')==0x10de and h('device')==0x2082, 'Only 10de:2082 is supported; 20c2/GA102 are refused')
    driver=(dev/'driver').resolve().name
    require(driver=='nvidia', 'This narrow build follows upstream loaded-driver workflow; NVIDIA must be bound')
    info=(Path('/proc/driver/nvidia/gpus')/bdf/'information').read_text()
    match=re.search(r'^GPU UUID:[ \t]*(' + UUID_PATTERN + r')[ \t]*$', info, re.M)
    require(match is not None, 'Live UUID unavailable: cannot bind state to physical GPU; do not bypass')
    result = {'uuid':match[1], 'bdf':bdf, 'vendor':h('vendor'), 'device':h('device'),
              'subvendor':h('subsystem_vendor'), 'subdevice':h('subsystem_device')}
    validate_identity(result)
    return result

def validate_identity(i):
    require(re.fullmatch(UUID_PATTERN, i['uuid']) is not None, 'Malformed live NVIDIA UUID')
    require(normalize_bdf(i['bdf']) == i['bdf'], 'Noncanonical PCI BDF')
    require((i['vendor'], i['device'], i['subvendor'], i['subdevice']) ==
            (0x10de, 0x2082, 0x10de, 0x1557), 'Unsupported PCI or subsystem ID')

def inventory():
    cards = []
    for path in sorted(Path('/sys/bus/pci/devices').iterdir()):
        if ((path/'vendor').read_text().strip(), (path/'device').read_text().strip()) != ('0x10de', '0x2082'):
            continue
        try:
            cards.append(identity(path.name))
        except (OSError, Refusal, ValueError) as exc:
            cards.append({'bdf': path.name, 'refused': str(exc)})
    return cards

def validate_environment(e):
    require(e['machine']=='x86_64', 'Expected x86_64')
    require('Open Kernel Module' in e['version_text'] and
            re.search(r'\b615\.71\.09\b', e['version_text']) and
            e['disk_version']=='615.71.09', 'Expected Open NVIDIA 615.71.09')
    require(e['disk_vermagic'].split()[:1] == [e['kernel']],
            'On-disk NVIDIA module vermagic differs from the running kernel')
    srcversion = DRIVER_BUILDS.get(e['disk_marker'])
    require(srcversion is not None, 'Unknown CMP170 driver packaging marker')
    require(e['loaded_srcversion']==srcversion and e['disk_srcversion']==srcversion,
            'Loaded/disk NVIDIA srcversion differs from the recorded build')

def burn_environment():
    def modinfo(field):
        return subprocess.check_output(['modinfo','-F',field,'nvidia'],text=True,timeout=5).strip()
    e={'kernel':platform.release(), 'machine':platform.machine(),
       'version_text':Path('/proc/driver/nvidia/version').read_text(),
       'disk_version':modinfo('version'), 'disk_vermagic':modinfo('vermagic'), 'disk_marker':modinfo('cmp170_10gb_package'),
       'loaded_srcversion':Path('/sys/module/nvidia/srcversion').read_text().strip(),
       'disk_srcversion':modinfo('srcversion')}
    validate_environment(e)
    path=Path(modinfo('filename'))
    require(path.is_file() and not path.is_symlink(), 'Driver file unavailable/symlink')
    e['driver_path']=str(path.resolve())
    e['driver_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
    return e

def no_clients():
    """Conservative: refuse clients on ANY NVIDIA/DRI node, not only target.
    Advisory lock cannot exclude in-kernel NVIDIA activity or outside tools.
    """
    nodes=set()
    for pat in ('/dev/nvidia*','/dev/nvidia-caps/*','/dev/dri/*'):
        for n in glob.glob(pat):
            try:
                s=os.stat(n)
                if stat.S_ISCHR(s.st_mode): nodes.add(s.st_rdev)
            except FileNotFoundError: pass
    require(nodes, 'No device nodes found: client scan cannot establish idle state')
    holders=set()
    for process in Path('/proc').iterdir():
        if not process.name.isdigit() or int(process.name)==os.getpid(): continue
        try:
            for fd in (process/'fd').iterdir():
                try:
                    s=fd.stat()
                    if stat.S_ISCHR(s.st_mode) and s.st_rdev in nodes: holders.add(process.name)
                except FileNotFoundError: pass
            # mmap may outlive its file descriptor: check device numbers in maps too.
            for line in (process/'maps').read_text().splitlines():
                fields=line.split(None,5)
                if len(fields)>=6 and re.search(r'^/dev/(nvidia|dri/)', fields[5]): holders.add(process.name)
        except (FileNotFoundError, ProcessLookupError): pass
        except PermissionError as e: raise Refusal('Cannot inspect all processes; idle state unknown') from e
    require(not holders, 'GPU/DRI clients exist (PIDs '+','.join(sorted(holders))+'). Stop them manually; no automatic service actions.')

class Native:
    def __init__(self):
        self.path=ROOT/'native/rirburn'
        require(self.path.is_file() and not self.path.is_symlink(), 'Build backend first: make')
        expected=(ROOT/'native/rirburn.sha256').read_text().strip()
        require(hashlib.sha256(self.path.read_bytes()).hexdigest()==expected, 'Backend hash mismatch; rebuild/review')
        self.hash=expected
    def run(self,bdf,mode,profile_id=None):
        args=[str(self.path), bdf, '--commit' if mode == '--burn' else mode]
        if profile_id is not None:
            args.append(profile_id)
        intent = 'CMP170-RIR-DURABLE-INTENT\n' if mode == '--burn' else None
        stdin = subprocess.PIPE if intent else subprocess.DEVNULL
        # Native signal handler retains control while the parent waits; no retries.
        # Inherited flock keeps competing coordinators out even if parent is killed.
        inherited=() if ACTIVE_LOCK_FD is None else (ACTIVE_LOCK_FD,)
        p=subprocess.Popen(args, stdin=stdin, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           text=True, start_new_session=True, pass_fds=inherited)
        try:
            out,_=p.communicate(input=intent,timeout=60)
        except BaseException:
            # Do not leave a child running when dropping the parent's lock.
            # Native handler stops waits; durable 'programming' blocks retries.
            p.terminate()
            try: p.communicate(timeout=10)
            except subprocess.TimeoutExpired:
                p.kill(); p.communicate()
            raise
        print(out,end='',flush=True)
        if p.returncode: raise Refusal('Native backend failed, exit='+str(p.returncode))
        return out
    def snapshot(self,bdf):
        out=self.run(bdf,'--snapshot')
        rows=[x[len('SNAPSHOT_JSON:'):] for x in out.splitlines() if x.startswith('SNAPSHOT_JSON:')]
        require(len(rows)==1, 'Missing/ambiguous native snapshot')
        try: value=json.loads(rows[0])
        except ValueError as e: raise Refusal('Malformed native snapshot') from e
        require(isinstance(value,dict), 'Invalid snapshot type')
        return value

def check_snapshot(s):
    keys={'rir','main','gate','iff','iffsw','en','en_prog','dis_prog','bypass','gpc','fbp','fbpa','lmr','cfg1','active','debug','fbpa_defective','plms','feat_plm'}
    require(isinstance(s,dict) and set(s)==keys, 'Incomplete snapshot')
    require(type(s['rir']) is list and type(s['main']) is list and type(s['plms']) is list,
            'Invalid snapshot array types')
    require(len(s['rir'])==8 and len(s['main'])==2 and len(s['plms'])==12, 'Invalid array sizes')
    for x in list(s['rir'])+list(s['main'])+[s[k] for k in keys-{'rir','main','plms','feat_plm'}]:
        require(type(x) is int and 0<=x<=0xffffffff and x!=0xffffffff, 'Invalid/all-ones readback: refuse this narrow profile')
    for x in s['plms']+[s['feat_plm']]:
        require(type(x) is int and 0<=x<=0xffffffff, 'Invalid PLM readback')

def profile(s,post=False):
    check_snapshot(s)
    require(s['iff']==STOCK_IFF and s['iffsw']==0, 'IFF state differs from reference')
    require(s['en_prog']==1 and s['dis_prog']==0 and s['bypass']==0, 'Programming flags/bypass differ')
    require((s['lmr'],s['cfg1'],s['active'])==(0x28a,0x02669000,10),
            'Unrecognized LMR/CFG1/FBPA geometry')
    profile_id = GEOMETRIES.get((s['gpc'], s['fbpa_defective']))
    require(profile_id is not None and (s['fbp'],s['fbpa'])==(0x840,0xc03000),
            'Unknown GPC/FBP/FBPA/defective mask combination')
    require(s['debug']==0 and s['plms']==[0xffffffff]*12 and s['feat_plm']==0xffffffff,
            'Recorded debug/PLM access state changed')
    if post:
        require(s['gate']==0 and s['rir']==[KEYSTONE]+[0]*7, 'Gate/RIR postburn mismatch')
        require(s['main']==[OLD_MAIN & ~(1<<5)]*2, 'Both main repair copies must match expected full words')
    else:
        require(s['en']==0, 'EN_SW_OVERRIDE must be zero after native preflight')
        require(s['gate']==1 and s['rir']==[0]*8 and s['main']==[OLD_MAIN]*2, 'Gate/main/RIR not pristine')
    return profile_id

class Coordinator:
    def __init__(self,backend,store,identify=identity,getboot=boot_id,idle=no_clients,environment=burn_environment,confirm=input):
        self.backend,self.store=backend,Path(store)
        self.identify,self.getboot,self.idle,self.environment,self.confirm=identify,getboot,idle,environment,confirm
    def path(self,i):
        require(re.fullmatch(UUID_PATTERN,i['uuid']) is not None, 'Malformed UUID')
        return self.store/(i['uuid']+'.json')
    def matching(self,st,i):
        require(st is not None and st.get('identity')==i, 'No matching state for live physical UUID/BDF; do not reuse foreign state')
        require(st.get('snapshot_digest')==digest(st.get('snapshot')), 'Saved snapshot changed')
        require(st.get('profile_id')==profile(st['snapshot']), 'Saved profile mismatches the snapshot')
        require(st.get('backend_sha256')==self.backend.hash, 'Backend changed since preflight')
    def save(self,p,st): atomic_json(p,st)
    def audit(self,i):
        bdf = i['bdf']
        snapshot = self.backend.snapshot(bdf)
        profile_id = profile(snapshot)
        self.backend.run(bdf, '--preflight', profile_id)
        require(self.backend.snapshot(bdf) == snapshot, 'Fuse snapshot changed during audit')
        return snapshot
    def preflight(self,bdf):
        i=self.identify(bdf);p=self.path(i);old=load_state(p)
        require(old is None or old.get('stage')=='prepared', 'Existing operation history cannot be reset by preflight')
        if old:
            # A card may move slots before intent. UUID remains the history key.
            prior = old.get('identity', {})
            require(prior.get('uuid') == i['uuid'], 'Prepared history belongs to another GPU')
            self.matching(old, dict(i, bdf=prior.get('bdf')))
        env=self.environment();require(isinstance(env,dict),'Environment fingerprint unavailable');self.idle()
        s=self.audit(i)
        require(self.identify(bdf)==i, 'GPU identity changed during preflight')
        require(self.environment()==env, 'Driver environment changed during preflight')
        st={'schema':SCHEMA,'profile_id':profile(s),'environment':env,'identity':i,'backend_sha256':self.backend.hash,'stage':'prepared',
            'prepared_boot_id':self.getboot(),'snapshot':s,'snapshot_digest':digest(s),'timestamp':time.time()}
        self.save(p,st)
        print(f"PREFLIGHT_OK {i['uuid']} {bdf} {st['profile_id']} {p}")
        print(json.dumps({'identity': i, 'snapshot': s}, indent=2))
        return st
    def burn(self,bdf,ack=False):
        require(ack, 'Pass --ack-bound-driver-risk after reviewing RUNBOOK-170.md.')
        i=self.identify(bdf);p=self.path(i);st=load_state(p);self.matching(st,i)
        require(st.get('stage')=='prepared', 'Operation started/complete/uncertain: NEVER retry; inspect state')
        require(st.get('prepared_boot_id')==self.getboot(), 'Re-run preflight in current boot before first attempt')
        env=self.environment();require(env==st.get('environment'),'Driver environment changed since preflight');self.idle()
        s=self.audit(i)
        require(digest(s)==st['snapshot_digest'], 'Snapshot changed since preflight')
        text='BURN '+i['uuid']+' '+bdf
        require(self.confirm('Irreversible: one word / two repair records. Type exactly "'+text+'":\n')==text, 'Confirmation mismatch')
        self.idle()
        require(self.identify(bdf)==i,'GPU identity changed')
        require(self.environment()==env, 'Driver environment changed before programming intent')
        require(self.backend.snapshot(bdf)==s, 'Fuse snapshot changed after confirmation')
        require(self.identify(bdf)==i and self.environment()==env,
                'GPU or environment changed before programming intent')
        # The native backend re-runs preflight immediately before programming.
        st.update(stage='programming',attempt_boot_id=self.getboot(),intent_timestamp=time.time())
        self.save(p,st)  # MUST complete durably before invoking any native burn.
        try:
            self.backend.run(bdf,'--burn',st['profile_id'])
            after=self.backend.snapshot(bdf)
            check_snapshot(after)
            require(after['rir']==[KEYSTONE]+[0]*7, 'Immediate RIR mismatch; no retry')
            for key in s.keys() - {'rir', 'main', 'gate'}:
                require(after[key] == s[key], 'Unexpected immediate change: ' + key)
            require(self.identify(bdf)==i, 'GPU identity changed after operation')
            require(self.environment()==env, 'Driver environment changed after operation')
            st.update(stage='written-await-powercycle',immediate=after)
            self.save(p,st)
        except BaseException as exc:
            st['attempt_error'] = f'{type(exc).__name__}: {exc}'
            # If this save fails too, the prior durable 'programming' still blocks retry.
            st['stage']='uncertain'
            try:self.save(p,st)
            except Exception:pass
            raise
        print('WRITE_READBACK_OK: shut down, physically remove power, boot and run postburn.')
    def postburn(self,bdf,power_confirmed=False):
        i=self.identify(bdf);p=self.path(i);st=load_state(p);self.matching(st,i)
        require(st.get('stage') in {'programming','uncertain','written-await-powercycle','verified'}, 'No recorded programming attempt')
        require(st.get('attempt_boot_id')!=self.getboot(), 'Same boot: cannot verify post-powercycle state')
        require(power_confirmed, 'New boot ID is insufficient; pass --confirm-power-removed only after actual removal')
        require(self.environment()==st.get('environment'), 'Driver environment changed since programming')
        self.idle()
        s=self.backend.snapshot(bdf)
        require(profile(s,post=True) == st['profile_id'], 'Postburn profile changed')
        require(self.environment()==st.get('environment'), 'Driver environment changed during postburn')
        require(self.identify(bdf)==i,'GPU identity changed')
        before=st['snapshot']
        for k in ('iff','iffsw','gpc','fbp','fbpa','lmr','cfg1','active','en_prog','dis_prog','bypass','debug','fbpa_defective','plms','feat_plm'):
            require(s[k]==before[k], 'Unexpected postburn change: '+k)
        st.update(stage='verified',postburn=s,verified_boot_id=self.getboot(),power_removal_operator_attested=True)
        self.save(p,st)
        print('POSTBURN_OK: RIR and gate verified after operator-attested power removal.')

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('command',choices=['list','status','preflight','burn','postburn','selftest','plan'])
    p.add_argument('--bdf')
    p.add_argument('--ack-bound-driver-risk',action='store_true')
    p.add_argument('--confirm-power-removed',action='store_true')
    a=p.parse_args(argv)
    if a.command=='selftest':
        require((((37<<2)|1)<<16)|((5<<2)|1)==KEYSTONE,'Encoding selftest failed')
        print('ENCODING_SELFTEST_OK (not hardware validation)');return 0
    if a.command=='list':
        print(json.dumps(inventory(), indent=2));return 0
    if a.command=='plan':
        print((ROOT/'RUNBOOK-170.md').read_text());return 0
    require(sys.platform=='linux' and platform.machine()=='x86_64' and os.geteuid()==0,'Linux x86_64 root required')
    require(a.bdf is not None,'Explicit --bdf required; no automatic target selection')
    bdf=normalize_bdf(a.bdf)
    def stop(signum, frame):
        raise KeyboardInterrupt
    for sig in (signal.SIGTERM, signal.SIGHUP):
        signal.signal(sig, stop)
    private_dir(STATE_ROOT)
    with exclusive_lock():
        n=Native();c=Coordinator(n,STATE_ROOT)
        if a.command=='status':
            i=identity(bdf);no_clients();s=n.snapshot(bdf);check_snapshot(s)
            print(json.dumps({'identity':i,'snapshot':s,'state':load_state(c.path(i))},indent=2));return 0
        if a.command=='preflight':c.preflight(bdf)
        elif a.command=='burn':
            require(a.ack_bound_driver_risk, 'Pass --ack-bound-driver-risk after reviewing the runbook')
            require(sys.stdin.isatty(), 'Burn confirmation requires a terminal')
            i = identity(bdf)
            if load_state(c.path(i)) is None:
                c.preflight(bdf)
            c.burn(bdf, a.ack_bound_driver_risk)
        else:c.postburn(bdf,a.confirm_power_removed)
    return 0

if __name__=='__main__':
    try:sys.exit(main())
    except KeyboardInterrupt:
        print('INTERRUPTED: operation may be uncertain; NEVER retry a started burn',file=sys.stderr);sys.exit(130)
    except (Refusal,OSError,ValueError,KeyError,subprocess.SubprocessError) as e:
        print('REFUSED/FAILED: '+str(e),file=sys.stderr);sys.exit(1)
